<?php
/**
* 2007-2014 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2014 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_'))
	exit;

require_once(_PS_MODULE_DIR_.'seur/AdminSeur.php');

function upgrade_module_1_3_1($module)
{
	if(!Configuration::get('SEUR_NACIONAL_SERVICE'))
		Configuration::updateValue('SEUR_NACIONAL_SERVICE', '031');
	
	if(!Configuration::get('SEUR_NACIONAL_PRODUCT'))
		Configuration::updateValue('SEUR_NACIONAL_PRODUCT', '002');
	
	if(!Configuration::get('SEUR_INTERNACIONAL_SERVICE'))
		Configuration::updateValue('SEUR_INTERNACIONAL_SERVICE', '077');
	
	if(!Configuration::get('SEUR_INTERNACIONAL_PRODUCT'))
		Configuration::updateValue('SEUR_INTERNACIONAL_PRODUCT', '070');
	
	AdminSeur::uninstallSeurCashOnDelivery();
	AdminSeur::installSeurCashOnDelivery();
    
	return $module;
}

?>
