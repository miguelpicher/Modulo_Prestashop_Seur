{*
 * 2007-2015 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2015 PrestaShop SA
 *  @version  Release: 0.4.4
 *  @license   http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 *}

{include file="./header.tpl"}


{if isset($email_warning_message)}
    {include file=$smarty.const._PS_MODULE_DIR_|escape:'htmlall':'UTF-8'|cat:'seur/views/templates/admin/warning_message.tpl' seur_warning_message=$email_warning_message|escape:'htmlall':'UTF-8'}
{/if}


<div class="header_setting">
    <div><a href="{$module_path}&merchant=1">{l s='Merchant' mod='seur'}</a></div>
    <div class="tab_select">{l s='Setting' mod='seur'}</div>
</div>


<form action="" method="POST">
    <div class="page_seur col-xs-12">

        <div class="title_seur col-xs-12">{l s="Cash on delivery" mod='seur'}</div>
        <div class="box_seur col_xs_12 row">
            <div class="col-xs-12 col-md-12 col-lg-12">
                <div class="label_seur">{l s='Active Cash on Delivery' mod='seur'}</div>
                <div class="input_seur">
                <span class="switch prestashop-switch fixed-width-lg">
                        <input type="radio" name="SEUR2_SETTINGS_COD" id="cashDelivery_on" value="1"
                               {if $cashDelivery}checked="checked"{/if}>
                        <label for="cashDelivery_on" class="radioCheck">{l s="Yes" mod="seur"}</label>
                        <input type="radio" name="SEUR2_SETTINGS_COD" id="cashDelivery_off" value="0"
                               {if !$cashDelivery}checked="checked"{/if}>
                        <label for="cashDelivery_off" class="radioCheck">{l s="No" mod="seur"}</label>
                        <a class="slide-button btn"></a>
                </span>
                </div>
            </div>
            <div class="col-xs-12 col-md-12 col-lg-6 row">
                <div class="col-xs-12 col-md-6 col-lg-3">
                    <div class="label_seur">{l s='Fee percent' mod='seur'}</div>
                    <div class="input_seur_mini"><input name="SEUR2_SETTINGS_COD_FEE_PERCENT" value="{$cod_fee_percent}"> %</div>
                </div>
                <div class="col-xs-12 col-md-6 col-lg-3">
                    <div class="label_seur">{l s='Min fee' mod='seur'}</div>
                    <div class="input_seur_mini"><input name="SEUR2_SETTINGS_COD_FEE_MIN" value="{$cod_fee_min}"> &euro;</div>
                </div>
                <div class="col-xs-12 col-md-6 col-lg-3">
                    <div class="label_seur">{l s='Min total available' mod='seur'}</div>
                    <div class="input_seur_mini"><input name="SEUR2_SETTINGS_COD_MIN" value="{$cod_min}"> &euro;</div>
                </div>
                <div class="col-xs-12 col-md-6 col-lg-3">
                    <div class="label_seur">{l s='Max total available' mod='seur'}</div>
                    <div class="input_seur_mini"><input name="SEUR2_SETTINGS_COD_MAX" value="{$cod_max}"> &euro;</div>
                </div>
                <div class="col-xs-12 col-md-12 col-lg-12">
                    <br>
                    <div class="note_seur">{l s="Enter a percentage to charge customers as a surcharge and/or a minimum amount if the percentage amount is not reached." mod='seur'}</div>
                </div>
            </div>
            <div class="col-xs-12 col-md-12 col-lg-12">
                <div class="label_seur">{l s='Show COD detailed taxes' mod='seur'}</div>
                <div class="input_seur">
                <span class="switch prestashop-switch fixed-width-lg">
                        <input type="radio" name="SEUR2_SETTINGS_COD_DETAILED_TAXES" id="cashDelivery_detailed_taxes_on" value="1"
                               {if $cashDelivery_detailed_taxes}checked="checked"{/if}>
                        <label for="cashDelivery_detailed_taxes_on" class="radioCheck">{l s="Yes" mod="seur"}</label>
                        <input type="radio" name="SEUR2_SETTINGS_COD_DETAILED_TAXES" id="cashDelivery_detailed_taxes_off" value="0"
                               {if !$cashDelivery_detailed_taxes}checked="checked"{/if}>
                        <label for="cashDelivery_detailed_taxes_off" class="radioCheck">{l s="No" mod="seur"}</label>
                        <a class="slide-button btn"></a>
                </span>
                </div>
            </div>
            <div class="col-xs-12 col-md-12 col-lg-6 row">
                <div class="col-xs-12 col-md-6 col-lg-3">
                    <div class="label_seur">{l s='COD Rate' mod='seur'}</div>
                    <div class="input_seur_mini"><input name="SEUR2_SETTINGS_COD_RATE" value="{$cod_rate}"> %</div>
                </div>
            </div>
        </div>

        <div class="title_seur col-xs-12">{l s="Print" mod='seur'}</div>
        <div class="box_seur col_xs_12 row">
            <div class="col-xs-12 col-md-12 col-lg-12">
                <div class="radio_seur">
                    <input type="radio" name="SEUR2_SETTINGS_PRINT_TYPE" value="1"
                           {if $print_type==1 }checked{/if}> {l s='Pdf' mod='seur'}
                    <input type="radio" name="SEUR2_SETTINGS_PRINT_TYPE" value="2"
                           {if $print_type==2 }checked{/if}> {l s='Label' mod='seur'}
                    <input type="radio" name="SEUR2_SETTINGS_PRINT_TYPE" value="3"
                           {if $print_type==3 }checked{/if}> {l s='A4_3' mod='seur'}
                </div>
                <div class="col-xs-12">
                    <div class="note_seur">{l s="Select PDF for normal printer. The thermal printer must be provided by SEUR." mod='seur'}</div>
                </div>
            </div>
            <div class="col-xs-12 col-md-12 col-lg-12">
                <div class="radio_seur">
                    <input type="radio" name="SEUR2_SETTINGS_LABEL_REFERENCE_TYPE" value="1"
                           {if $label_reference_type==1 }checked{/if}> {l s='Order Reference' mod='seur'}
                    <input type="radio" name="SEUR2_SETTINGS_LABEL_REFERENCE_TYPE" value="2"
                           {if $label_reference_type==2 }checked{/if}> {l s='Order Id' mod='seur'}
                </div>
                <div class="col-xs-12">
                    <div class="note_seur">{l s="Identifier to display on the label" mod='seur'}</div>
                </div>
            </div>
        </div>

        <div class="title_seur col-xs-12">{l s="Collection" mod='seur'}</div>
        <div class="box_seur col_xs_12 row">
            <div class="radio_seur col-xs-3 col-md-2 col-lg-1">
                <input type="radio" name="SEUR2_SETTINGS_PICKUP" value="1"
                       {if $collection_type==1 }checked{/if}> {l s='Automatic' mod='seur'}
            </div>
            <div class="col-xs-9 col-md-10 col-lg-11">
                <div class="radio_seur note_seur">{l s="Automatic collection is generated automatically with the first order of the day." mod='seur'}</div>
            </div>
            <div class="xs-hidden md-hidden col-lg-12 sin-padding"></div>
            <div class="radio_seur col-xs-3 col-md-2 col-lg-1">
                <input type="radio" name="SEUR2_SETTINGS_PICKUP" value="2"
                       {if $collection_type==2 }checked{/if}> {l s='Fix' mod='seur'}
            </div>
            <div class="col-xs-9 col-md-10 col-lg-11">
                <div class="radio_seur note_seur">{l s="The fixed collection must be contracted with SEUR to be collected every day." mod='seur'}</div>
            </div>
        </div>


        <div class="title_seur col-xs-12">{l s="Google Api key" mod='seur'}</div>

        <div class="box_seur col_xs_12 row">
            <div class="col-xs-12 col-md-6 col-lg-3">
                <div class="label_seur">{l s="Google Api key" mod='seur'}</div>
                <div class="input_seur"><input name="SEUR2_GOOGLE_API_KEY" value="{$google_key}"></div>
            </div>
            <div class="col-xs-12 col-md-6 col-lg-3">
                <div class="label_seur">&nbsp;</div>
                <div class="note_seur">{l s="You must have an API access key provided by Google. To obtain one, go to the following address and follow the instructions: https://developers.google.com/maps" mod='seur'} <!--a href="#">{l s="Click here" mod='seur'}</a-->
                </div>
            </div>
        </div>

        <div class="title_seur col-xs-12">{l s="Automatic labels creation" mod='seur'}</div>
        <div class="box_seur col_xs_12 row">
          <div class="col-xs-6 col-md-6 col-lg-6">
            <div class="label_seur">{l s='Active' mod='seur'}</div>
            <div class="input_seur">
                    <span class="switch prestashop-switch fixed-width-lg">
                            <input type="radio" name="SEUR2_AUTO_CREATE_LABELS" id="generationLabel_on" value="1"
                                   {if $auto_create_labels}checked="checked"{/if}>
                            <label for="generationLabel_on" class="radioCheck">{l s="Yes" mod="seur"}</label>
                            <input type="radio" name="SEUR2_AUTO_CREATE_LABELS" id="generationLabel_off" value="0"
                                   {if !$auto_create_labels}checked="checked"{/if}>
                            <label for="generationLabel_off" class="radioCheck">{l s="No" mod="seur"}</label>
                            <a class="slide-button btn"></a>
                    </span>
            </div>
          </div>
          <div class="col-xs-6 col-md-6 col-lg-6">
            <div class="label_seur">{l s='Payments Methods' mod='seur'}</div>
            <div class="note_seur">{l s="Select the payment methods that will be active for automatic label creation." mod='seur'}</div>
            <div class="note_seur">{l s="Press Control or Shift to select more than 1." mod='seur'}</div>
              <div class="input_seur">
                <select name="SEUR2_AUTO_CREATE_LABELS_PAYMENTS_METHODS_AVAILABLE[]" id="payment_methods" multiple>
                    {foreach $payments_methods as $payment}
                        {assign var="selected" value=""}
                        {if in_array($payment['name'], $auto_create_labels_payments_methods_available)}
                            {assign var="selected" value="selected"}
                        {/if}
                        <option value="{$payment['name']}" {$selected}>{$payment['displayName']}</option>
                    {/foreach}
                </select>
            </div>
          </div>
        </div>

        <div class="title_seur col-xs-12">{l s="Automatic packages creation" mod='seur'}</div>
        <div class="box_seur col_xs_12 row">
          <div class="col-xs-12 col-md-12 col-lg-12">
            <div class="label_seur">{l s='Active' mod='seur'}</div>
            <div class="input_seur">
              <span class="switch prestashop-switch fixed-width-lg">
                      <input type="radio" name="SEUR2_AUTO_CALCULATE_PACKAGES" id="generationPackages_on" value="1"
                             {if $auto_calculate_packages}checked="checked"{/if}>
                      <label for="generationPackages_on" class="radioCheck">{l s="Yes" mod="seur"}</label>
                      <input type="radio" name="SEUR2_AUTO_CALCULATE_PACKAGES" id="generationPackages_off" value="0"
                             {if !$auto_calculate_packages}checked="checked"{/if}>
                      <label for="generationPackages_off" class="radioCheck">{l s="No" mod="seur"}</label>
                      <a class="slide-button btn"></a>
              </span>
            </div>
          </div>
        </div>

        <div class="title_seur col-xs-12">{l s="Capture orders from other carriers" mod='seur'}</div>
        <div class="box_seur col_xs_12 row">
            <div class="col-xs-12 col-md-6 col-lg-6">
                <div class="label_seur">{l s='Active capture orders' mod='seur'}</div>
                <div class="input_seur">
                <span class="switch prestashop-switch fixed-width-lg">
                        <input type="radio" name="SEUR2_CAPTURE_ORDER" id="captureOrder_on" value="1"
                               {if $capture_order}checked="checked"{/if}>
                        <label for="captureOrder_on" class="radioCheck">{l s="Yes" mod="seur"}</label>
                        <input type="radio" name="SEUR2_CAPTURE_ORDER" id="captureOrder_off" value="0"
                               {if !$capture_order}checked="checked"{/if}>
                        <label for="captureOrder_off" class="radioCheck">{l s="No" mod="seur"}</label>
                        <a class="slide-button btn"></a>
                </span>
                </div>
            </div>
            <div class="col-xs-12 col-md-6 col-lg-6">
                <div class="label_seur">{l s='Recalculate shipment cost' mod='seur'}</div>
                <div class="input_seur">
                <span class="switch prestashop-switch fixed-width-lg">
                        <input type="radio" name="SEUR2_RECALCULATE_SHIPMENT_COST" id="recalculateShipment_on" value="1"
                               {if $recalculateShipment}checked="checked"{/if}>
                        <label for="recalculateShipment_on" class="radioCheck">{l s="Yes" mod="seur"}</label>
                        <input type="radio" name="SEUR2_RECALCULATE_SHIPMENT_COST" id="recalculateShipment_off" value="0"
                               {if !$recalculateShipment}checked="checked"{/if}>
                        <label for="recalculateShipment_off" class="radioCheck">{l s="No" mod="seur"}</label>
                        <a class="slide-button btn"></a>
                </span>
                </div>
            </div>
        </div>
        <div class="title_seur col-xs-12">{l s="Enable bulk carrier assignment" mod='seur'}</div>
        <div class="box_seur col_xs_12 row">
            <div class="col-xs-12 col-md-6 col-lg-6">
                <div class="label_seur">{l s='Active' mod='seur'}</div>
                <div class="input_seur">
                <span class="switch prestashop-switch fixed-width-lg">
                        <input type="radio" name="SEUR2_BULK_ASSIGN_CARRIER" id="bulkAssignCarrier_on" value="1"
                               {if $bulk_assign_carrier}checked="checked"{/if}>
                        <label for="bulkAssignCarrier_on" class="radioCheck">{l s="Yes" mod="seur"}</label>
                        <input type="radio" name="SEUR2_BULK_ASSIGN_CARRIER" id="bulkAssignCarrier_off" value="0"
                               {if !$bulk_assign_carrier}checked="checked"{/if}>
                        <label for="bulkAssignCarrier_off" class="radioCheck">{l s="No" mod="seur"}</label>
                        <a class="slide-button btn"></a>
                </span>
                </div>
            </div>
            <div class="col-xs-12 col-md-6 col-lg-6">
                <div class="label_seur">{l s='This never change shipment cost' mod='seur'}</div>
            </div>
        </div>

        <div class="title_seur col-xs-12">{l s="Enable SEUR Returns site" mod='seur'}</div>
        <div class="box_seur col_xs_12 row">
            <div class="col-xs-12 col-md-12 col-lg-12">
                <div class="label_seur">{l s='Active' mod='seur'}</div>
                <div class="input_seur">
                <span class="switch prestashop-switch fixed-width-lg">
                        <input type="radio" name="SEUR2_ACTIVE_RETURNS_SITE_LINK" id="activeReturnsSiteLink_on" value="1"
                               {if $active_returns_site_link}checked="checked"{/if}>
                        <label for="activeReturnsSiteLink_on" class="radioCheck">{l s="Yes" mod="seur"}</label>
                        <input type="radio" name="SEUR2_ACTIVE_RETURNS_SITE_LINK" id="activeReturnsSiteLink_off" value="0"
                               {if !$active_returns_site_link}checked="checked"{/if}>
                        <label for="activeReturnsSiteLink_off" class="radioCheck">{l s="No" mod="seur"}</label>
                        <a class="slide-button btn"></a>
                </span>
                </div>
            </div>
            <div class="col-xs-12 col-md-12 col-lg-12">
                <div class="label_seur">{l s="SEUR Returns site url" mod='seur'}</div>
                <div class="input_seur"><input name="SEUR2_RETURNS_SITE_URL" value="{$returns_site_url}"></div>
            </div>
        </div>
        <div class="title_seur col-xs-12">{l s="Status Seur" mod='seur'}</div>
        <div class="box_seur col_xs_12 row">
            <div class="col-xs-12 col-md-12 col-lg-12">
                <div class="label_seur">{l s='Automatically change the status of orders to ‘Shipped’:' mod='seur'}</div>
                <div class="radio_seur">
                    <input type="radio" name="SEUR2_MARK_SENDED" id="sended_off" value="0" {if $sended_when==0}checked="checked"{/if}>
                    {l s="Nunca" mod="seur"}
                    <input type="radio" name="SEUR2_MARK_SENDED" id="sended_labeled" value="1" {if $sended_when==1}checked="checked"{/if}>
                    {l s="Al etiquetar" mod="seur"}
                    <input type="radio" name="SEUR2_MARK_SENDED" id="sended_manifested" value="2" {if $sended_when==2}checked="checked"{/if}>
                    {l s="Al generar el Manifiesto" mod="seur"}
                </div>
            </div>
            <div class="col-xs-12 col-md-6 col-lg-3">
                <div class="label_seur">{l s='In transit' mod='seur'}</div>
                <div class="input_seur">{include file='./select_status_ps.tpl' name_select='SEUR2_STATUS_IN_TRANSIT' status_ps=$status_ps value=$status_in_transit}</div>
            </div>
            <div class="col-xs-12 col-md-6 col-lg-3">
                <div class="label_seur">{l s='Return in progress' mod='seur'}</div>
                <div class="input_seur">{include file='./select_status_ps.tpl' name_select='SEUR2_STATUS_RETURN_IN_PROGRESS' status_ps=$status_ps value=$status_return_in_progress}</div>
            </div>
            <div class="col-xs-12 col-md-6 col-lg-3">
                <div class="label_seur">{l s='Available to pick up in store' mod='seur'}</div>
                <div class="input_seur">{include file='./select_status_ps.tpl' name_select='SEUR2_STATUS_AVAILABLE_IN_STORE' status_ps=$status_ps value=$status_available_in_store}</div>
            </div>
            <div class="xs-hidden md-hidden col-lg-12 sin-padding"></div>
            <div class="col-xs-12 col-md-6 col-lg-3">
                <div class="label_seur">{l s='Contribute solution' mod='seur'}</div>
                <div class="input_seur">{include file='./select_status_ps.tpl' name_select='SEUR2_STATUS_CONTRIBUTE_SOLUTION' status_ps=$status_ps value=$status_contribute_solution}</div>
            </div>
            <div class="col-xs-12 col-md-6 col-lg-3">
                <div class="label_seur">{l s='Delivered' mod='seur'}</div>
                <div class="input_seur">{include file='./select_status_ps.tpl' name_select='SEUR2_STATUS_DELIVERED' status_ps=$status_ps value=$status_delivered}</div>
            </div>
            <div class="col-xs-12 col-md-6 col-lg-3">
                <div class="label_seur">{l s='Incidence' mod='seur'}</div>
                <div class="input_seur">{include file='./select_status_ps.tpl' name_select='SEUR2_STATUS_INCIDENCE' status_ps=$status_ps value=$status_incidence}</div>
            </div>
        </div>

        <div class="title_seur col-xs-12">{l s="Automatic Update Shipments Status" mod='seur'} - SEUR Cron</div>
        <div class="box_seur col_xs_12 row">
            <div class="col-xs-12 col-md-6 col-lg-3">
                <div class="label_seur">{l s='Active' mod='seur'}</div>
                <div class="input_seur">
                <span class="switch prestashop-switch fixed-width-lg">
                        <input type="radio" name="SEUR2_UPDATE_SHIPMENT_CRON" id="activeUpdateShipmentCron_on" value="1"
                               {if $update_shipments_cron}checked="checked"{/if}>
                        <label for="activeUpdateShipmentCron_on" class="radioCheck">{l s="Yes" mod="seur"}</label>
                        <input type="radio" name="SEUR2_UPDATE_SHIPMENT_CRON" id="activeUpdateShipmentCron_off" value="0"
                               {if !$update_shipments_cron}checked="checked"{/if}>
                        <label for="activeUpdateShipmentCron_off" class="radioCheck">{l s="No" mod="seur"}</label>
                        <a class="slide-button btn"></a>
                    <input type="hidden" name="SEUR2_UPDATE_SHIPMENT_CRON_OLD_VALUE" value="{$update_shipments_cron}">
                </span>
                </div>
            </div>
            <div class="col-xs-12 col-md-6 col-lg-3">
                <div class="label_seur">{l s='Interval' mod='seur'}</div>
                <div class="input_seur">
                    <select name='SEUR2_UPDATE_SHIPMENT_INTERVAL' id='select_update_shipment_interval'>
                        <option value="3600" {if $update_shipments_interval==3600}selected{/if}>{l s='Hourly' mod='seur'}</option>
                        <option value="14400" {if $update_shipments_interval==14400}selected{/if}>{l s='Every 4 hours' mod='seur'}</option>
                    </select>
                    <input type="hidden" name="SEUR2_UPDATE_SHIPMENT_INTERVAL_OLD_VALUE" value="{$update_shipments_interval}">
                </div>
            </div>
            <div class="col-xs-12 col-md-6 col-lg-3">
                <div class="label_seur">{l s='Last Execution' mod='seur'}</div>
                <div class="input_seur">{$update_shipments_last_execution}</div>
            </div>
            <div class="col-xs-12 col-md-6 col-lg-3">
                <div class="label_seur">{l s='Next Execution' mod='seur'}</div>
                <div class="input_seur">{$update_shipments_next_execution}</div>
            </div>
        </div>
        {if !$update_shipments_cron}
        <div class="title_seur col-xs-12">{l s="Automatic Update Shipments Status" mod='seur'} - {l s="System Cron" mod='seur'}</div>
        <div class="cron-alerts">
            <div class="alert alert-info">
                {l s='You can set up a scheduled task to refresh the status of your shipments using the following URL:' mod='seur'}
                <br><br>
                <strong>{$module_url}module/seur/updateshipments?secret={$module_secret}</strong>
            </div>
            <div class="alert alert-info">
                {l s='Alternatively, if you have access to the system console, you can create a CRON job like:' mod='seur'}
                <br><br>
                <strong><code>* * * * * curl -s {$module_url}module/seur/updateshipments?secret={$module_secret}</code></strong>
            </div>
        </div>
        {/if}
    <div class='clearfix'>
        <button type="submit" name="submitSettingsSeur" class="btn btn-default submitSeur"><i class="icon-save"></i> {l s="Save" mod="seur"}</button>
    </div>
        <script>
            $(document).ready(function(){
                $(".bootstrap.panel").hide();
            });
        </script>

    </div>
</form>
